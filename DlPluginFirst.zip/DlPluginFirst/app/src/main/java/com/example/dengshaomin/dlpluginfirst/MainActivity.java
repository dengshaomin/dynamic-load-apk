package com.example.dengshaomin.dlpluginfirst;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.dengshaomin.dlpluginhost.HostMethod;
import com.example.plugininterface.PluginIterface;
import com.ryg.dynamicload.DLBasePluginActivity;

public class MainActivity extends DLBasePluginActivity implements PluginIterface {
    String versionName = "1.5";
    private WindowManager wm = null;
    private WindowManager.LayoutParams wmParams = null;
    private ImageView leftbtn;

    /**
     * 应为是通过占坑，代理进来的，所有获取到的context都为宿主的context
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        that.setContentView(R.layout.activity_main);
        findViewById(R.id.text).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("code", "调用宿主方法:" + HostMethod.getVersionName());
            }
        });
        //获取的context为宿主context,获取的版本号为宿主版本号
        versionName = getAppVersionName(getApplicationContext());
    }

    @Override
    public String getPluginVersion() {
        return versionName;
    }

    @Override
    public View showFloatView(Activity activity) {
        wm = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
//        //设置LayoutParams(全局变量）相关参数
        wmParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);

        wmParams.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
        //以屏幕左上角为原点，设置x、y初始值
        wmParams.x = 0;
        wmParams.y = 0;
        //设置悬浮窗口长宽数据
        wmParams.width = 200;
        wmParams.height = 200;
        createLeftFloatView(activity);
        leftbtn.invalidate();
        return leftbtn;
    }

    @Override
    public void hostFinish(Activity activity,View view) {
        wm = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
        if (wm != null && view != null) {
            Log.e("code", "remove floatView");
            wm.removeViewImmediate(view);
        }
    }

    private void createLeftFloatView(final Activity activity) {
        leftbtn = new ImageView(activity);
        leftbtn.setImageResource(R.mipmap.ic_launcher);
        leftbtn.setAlpha(100);
        leftbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this,"click",Toast.LENGTH_SHORT).show();
            }
        });
        //调整悬浮窗口
        //显示myFloatView图像
        wm.addView(leftbtn, wmParams);
        leftbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity, "float", Toast.LENGTH_SHORT).show();
            }
        });
        leftbtn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (wm != null) {
                    wm.removeViewImmediate(leftbtn);
                }
//                Toast.makeText(MainActivity.this, "finish", Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        leftbtn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                // 当前值以屏幕左上角为原点
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        mStartX = event.getRawX();
                        mStartY = event.getRawY();
                        break;

                    case MotionEvent.ACTION_MOVE:
                        wmParams.x += event.getRawX() - mStartX;
                        wmParams.y += event.getRawY() - mStartY;
                        wm.updateViewLayout(leftbtn, wmParams);
                        mStartX = event.getRawX();
                        mStartY = event.getRawY();
                        break;
                    case MotionEvent.ACTION_UP:
                        break;
                }

                // 消耗触摸事件
                return true;

            }
        });
    }


    private float mStartX, mStartY;

    private String getAppVersionName(Context context) {
        String versionName = "1.1";
        try {
            // ---get the package info---
            PackageManager pm = context.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(context.getPackageName(), 0);
            versionName = pi.versionName;
//            versioncode = pi.versionCode;
            if (versionName == null || versionName.length() <= 0) {
                return "";
            }
        } catch (Exception e) {
            Log.e("VersionInfo", "Exception", e);
        }
        return versionName;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
