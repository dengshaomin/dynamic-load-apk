package com.example.dengshaomin.dlpluginhost;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

/**
 * Created by dengshaomin on 2017/7/5.
 */

public class HostMethod {
    public static String getVersionName() {
        return null;
    }
}
