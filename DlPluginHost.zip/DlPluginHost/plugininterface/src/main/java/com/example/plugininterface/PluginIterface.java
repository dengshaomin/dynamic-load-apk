package com.example.plugininterface;

import android.app.Activity;
import android.view.View;

/**
 * Created by dengshaomin on 2017/7/5.
 */
public interface PluginIterface {
    String getPluginVersion();

    View showFloatView(Activity activity);

    void hostFinish(Activity activity,View view);
}
