package com.example.dengshaomin.dlpluginhost;

import android.app.Application;
import android.content.Context;


/**
 * Created by dengshaomin on 2017/7/5.
 */

public class MyApplication extends Application {

    public static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        this.context = getApplicationContext();
    }

}
