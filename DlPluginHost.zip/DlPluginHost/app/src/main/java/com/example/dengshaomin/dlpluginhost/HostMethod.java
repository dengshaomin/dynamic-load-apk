package com.example.dengshaomin.dlpluginhost;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

/**
 * Created by dengshaomin on 2017/7/5.
 */

public class HostMethod {
    public static String getVersionName() {
        String versionName = "1.2";
        try {
            // ---get the package info---
            PackageManager pm = MyApplication.context.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(MyApplication.context.getPackageName(), 0);
            versionName = pi.versionName;
//            versioncode = pi.versionCode;
            if (versionName == null || versionName.length() <= 0) {
                return "";
            }
        } catch (Exception e) {
            Log.e("VersionInfo", "Exception", e);
        }
        return versionName;
    }
}
