package com.example.dengshaomin.dlpluginhost;

import android.app.Activity;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.ryg.dynamicload.internal.DLIntent;
import com.ryg.dynamicload.internal.DLPluginManager;
import com.ryg.utils.DLUtils;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends Activity implements AdapterView.OnItemClickListener {

    public static final String FROM = "extra.from";
    public static final int FROM_INTERNAL = 0;
    public static final int FROM_EXTERNAL = 1;

    private ArrayList<PluginItem> mPluginItems = new ArrayList<PluginItem>();
    private PluginAdapter mPluginAdapter;

    private ListView mListView;
    private TextView mNoPluginTextView;
    private View pluginFloatView;
    private ServiceConnection mConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
    }

    private void initView() {
        mPluginAdapter = new PluginAdapter();
        mListView = (ListView) findViewById(R.id.plugin_list);
        mNoPluginTextView = (TextView) findViewById(R.id.no_plugin);
        findViewById(R.id.invokePluginMethod).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                invokePluginMethod1();
            }
        });
    }

    private void initData() {
        String pluginFolder = Environment.getExternalStorageDirectory() + "/DynamicLoadHost";
        if (!new File(pluginFolder).exists()) {
            new File(pluginFolder).mkdirs();
        }
        File file = new File(pluginFolder);
        File[] plugins = file.listFiles();
        if (plugins == null || plugins.length == 0) {
            mNoPluginTextView.setVisibility(View.VISIBLE);
            return;
        }

        for (File plugin : plugins) {
            PluginItem item = new PluginItem();
            item.pluginPath = plugin.getAbsolutePath();
            item.packageInfo = DLUtils.getPackageInfo(this, item.pluginPath);
            if (item.packageInfo.activities != null && item.packageInfo.activities.length > 0) {
                item.launcherActivityName = item.packageInfo.activities[0].name;
            }
            if (item.packageInfo.services != null && item.packageInfo.services.length > 0) {
                item.launcherServiceName = item.packageInfo.services[0].name;
            }
            mPluginItems.add(item);
            DLPluginManager.getInstance(this).loadApk(item.pluginPath);
        }

        mListView.setAdapter(mPluginAdapter);
        mListView.setOnItemClickListener(this);
        mPluginAdapter.notifyDataSetChanged();
    }


    private class PluginAdapter extends BaseAdapter {

        private LayoutInflater mInflater;

        public PluginAdapter() {
            mInflater = MainActivity.this.getLayoutInflater();
        }

        @Override
        public int getCount() {
            return mPluginItems.size();
        }

        @Override
        public Object getItem(int position) {
            return mPluginItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = mInflater.inflate(R.layout.plugin_item, parent, false);
                holder = new ViewHolder();
                holder.appIcon = (ImageView) convertView.findViewById(R.id.app_icon);
                holder.appName = (TextView) convertView.findViewById(R.id.app_name);
                holder.apkName = (TextView) convertView.findViewById(R.id.apk_name);
                holder.packageName = (TextView) convertView.findViewById(R.id.package_name);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            PluginItem item = mPluginItems.get(position);
            PackageInfo packageInfo = item.packageInfo;
            holder.appIcon.setImageDrawable(DLUtils.getAppIcon(MainActivity.this, item.pluginPath));
            holder.appName.setText(DLUtils.getAppLabel(MainActivity.this, item.pluginPath));
            holder.apkName.setText(item.pluginPath.substring(item.pluginPath.lastIndexOf(File.separatorChar) + 1));
            holder.packageName.setText(packageInfo.applicationInfo.packageName + "\n" +
                    item.launcherActivityName + "\n" +
                    item.launcherServiceName);
            return convertView;
        }
    }

    private static class ViewHolder {
        public ImageView appIcon;
        public TextView appName;
        public TextView apkName;
        public TextView packageName;
    }

    public static class PluginItem {
        public PackageInfo packageInfo;
        public String pluginPath;
        public String launcherActivityName;
        public String launcherServiceName;

        public PluginItem() {
        }
    }

    /**
     * 插件加载时候调用，只有生命周期开始了调用才有意义. 或者直接传入activity，比如说游戏sdk在游戏上显示悬浮窗
     */
    private void invokePluginMethod() {
        if (mPluginItems != null && mPluginItems.size() > 0) {
            PluginItem item = mPluginItems.get(0);
            DLPluginManager pluginManager = DLPluginManager.getInstance(this);
            Log.e("code", "调用插件方法:" + pluginManager.invokePrivateMothod(item.packageInfo.packageName, item
                    .launcherActivityName).getPluginVersion());
        }
    }
    /**
     * 插件加载时候调用，只有生命周期开始了调用才有意义. 或者直接传入activity，比如说游戏sdk在游戏上显示悬浮窗
     */
    private void invokePluginMethod1() {
        if (mPluginItems != null && mPluginItems.size() > 0) {
            PluginItem item = mPluginItems.get(0);
            DLPluginManager pluginManager = DLPluginManager.getInstance(this);

            //开启插件悬浮窗
            pluginFloatView = pluginManager.invokePrivateMothod(item.packageInfo.packageName, item
                    .launcherActivityName).showFloatView(this);
        }
    }
    /**
     * 插件加载时候调用，只有生命周期开始了调用才有意义. 或者直接传入activity，比如说游戏sdk在游戏上显示悬浮窗
     */
    private void invokePluginMethod2() {
        if (mPluginItems != null && mPluginItems.size() > 0) {
            PluginItem item = mPluginItems.get(0);
            DLPluginManager pluginManager = DLPluginManager.getInstance(this);

            pluginManager.invokePrivateMothod( item.packageInfo.packageName, item
                    .launcherActivityName).hostFinish(MainActivity.this,pluginFloatView);
        }
    }
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        PluginItem item = mPluginItems.get(position);
        DLPluginManager pluginManager = DLPluginManager.getInstance(this);
        pluginManager.startPluginActivity(this, new DLIntent(item.packageInfo.packageName, item.launcherActivityName));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                invokePluginMethod();
            }
        }, 2000);
        //如果存在Service则调用起Service
//        if (item.launcherServiceName != null) {
//            //startService
//	        DLIntent intent = new DLIntent(item.packageInfo.packageName, item.launcherServiceName);
//	        //startService
//            pluginManager.startPluginService(this, intent);
//
////            bindService
//            pluginManager.bindPluginService(this, intent, mConnection = new ServiceConnection() {
//                public void onServiceDisconnected(ComponentName name) {
//                }
//
//                public void onServiceConnected(ComponentName name, IBinder binder) {
//                    int sum = ((ITestServiceInterface) binder).sum(5, 5);
//                    Log.e("MainActivity", "onServiceConnected sum(5 + 5) = " + sum);
//                }
//            }, Context.BIND_AUTO_CREATE);
//        }

    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        if (mConnection != null) {
            this.unbindService(mConnection);
        }
        //移除悬浮窗
        invokePluginMethod2();
    }
}
